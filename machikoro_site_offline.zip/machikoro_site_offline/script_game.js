
// 街ころ (オフライン版) — データ埋め込み済み
let GAME = { players: [], data: null, bank: 10000, current: 0, playerCount: 2 };

// データを直書き
GAME.data = {
  "buildings": [
    {"name": "農場", "emoji": "🌾", "dice": "1", "effect_type": "bank_gain", "value": 1, "cost": 1, "type": "basic"},
    {"name": "カフェ", "emoji": "☕", "dice": "2-3", "effect_type": "steal_from_roller", "value": 1, "cost": 2, "type": "basic"},
    {"name": "パン屋", "emoji": "🥐", "dice": "3", "effect_type": "bank_gain", "value": 1, "cost": 1, "type": "basic"},
    {"name": "森", "emoji": "🌲", "dice": "4", "effect_type": "bank_gain", "value": 2, "cost": 3, "type": "basic"},
    {"name": "鉱山", "emoji": "⛏", "dice": "6", "effect_type": "bank_gain", "value": 5, "cost": 6, "type": "basic"},
    {"name": "市場", "emoji": "🛒", "dice": "5", "effect_type": "gain_from_all", "value": 1, "cost": 4, "type": "special"},
    {"name": "レストラン", "emoji": "🍴", "dice": "8", "effect_type": "steal_from_roller", "value": 2, "cost": 3, "type": "special"},
    {"name": "スタジアム", "emoji": "⚽", "dice": "9-10", "effect_type": "gain_from_all", "value": 2, "cost": 6, "type": "special"}
  ],
  "landmarks": [
    {"name": "市役所", "emoji": "🏛", "cost": 4, "effect": "if_zero_start_gain_1", "key": "town_hall"},
    {"name": "駅", "emoji": "🚉", "cost": 4, "effect": "roll_two_dice", "key": "station"},
    {"name": "遊園地", "emoji": "🎡", "cost": 10, "effect": "extra_turn_on_double", "key": "amusement_park"},
    {"name": "ショッピングモール", "emoji": "🏬", "cost": 12, "effect": "food_bonus_plus1", "key": "mall"}
  ]
};

function log(msg) {
  const el = document.getElementById('log');
  const p = document.createElement('div');
  p.textContent = msg;
  el.prepend(p);
}

function setupPlayers(n){
  GAME.players = [];
  for(let i=0;i<n;i++){
    GAME.players.push({
      id: i,
      name: 'P' + (i+1),
      coins: 5,
      buildings: [],
      landmarks: {}, // key: built boolean
      hasStation: false
    });
    GAME.data.landmarks.forEach(l => GAME.players[i].landmarks[l.key] = false);
  }
  GAME.playerCount = n;
  GAME.current = 0;
  renderPlayers();
  renderShop();
  renderActivePlayer();
  log('ゲーム開始。プレイヤーに5コインを配布しました。');
}

function renderPlayers(){
  const wrap = document.getElementById('players');
  wrap.innerHTML = '';
  GAME.players.forEach(p=>{
    const d = document.createElement('div');
    d.className = 'player' + (GAME.current===p.id ? ' active' : '');
    d.id = 'player-'+p.id;
    d.innerHTML = `<div>${p.name} — ${p.coins}コイン</div><div style="font-size:12px">建物:${p.buildings.length} / ランド:${Object.values(p.landmarks).filter(x=>x).length}</div>`;
    wrap.appendChild(d);
  });
}

function renderShop(){
  const shop = document.getElementById('shop');
  shop.innerHTML = '';
  GAME.data.buildings.forEach(b=>{
    const c = document.createElement('div');
    c.className = 'card';
    c.innerHTML = `<div>${b.emoji} <strong>${b.name}</strong></div><div style="font-size:12px">目: ${b.dice} / 効果: ${b.effect_type} ${b.value}</div><div style="margin-top:6px"><button class="btn" onclick="buyBuilding('${b.name}')">購入 (${b.cost})</button></div>`;
    shop.appendChild(c);
  });
  GAME.data.landmarks.forEach(l=>{
    const c = document.createElement('div');
    c.className = 'card';
    c.innerHTML = `<div>${l.emoji} <strong>${l.name}</strong></div><div style="font-size:12px">コスト: ${l.cost}</div><div style="margin-top:6px"><button class="btn" onclick="buyLandmark('${l.key}')">建設 (${l.cost})</button></div>`;
    shop.appendChild(c);
  });
}

function buyBuilding(name){
  const player = GAME.players[GAME.current];
  const b = GAME.data.buildings.find(x=>x.name===name);
  if(!b){ alert('建物が見つかりません'); return; }
  if(player.coins < b.cost){ alert('コインが足りません'); return; }
  player.coins -= b.cost;
  player.buildings.push(Object.assign({}, b));
  renderPlayers(); renderMyArea();
  log(`${player.name} が ${b.name} を建てた（残り ${player.coins}コイン）。`);
}

function buyLandmark(key){
  const player = GAME.players[GAME.current];
  const l = GAME.data.landmarks.find(x=>x.key===key);
  if(!l){ alert('ランドマークが見つかりません'); return; }
  if(player.landmarks[key]){ alert('既に建設済みです'); return; }
  if(player.coins < l.cost){ alert('コインが足りません'); return; }
  player.coins -= l.cost;
  player.landmarks[key] = true;
  if(key==='station') player.hasStation = true;
  renderPlayers(); renderMyArea();
  log(`${player.name} が ${l.name} を建設した。`);
  checkVictory(player);
}

function parseDiceSpec(spec){
  const parts = spec.split(/\s*,\s*/);
  const set = new Set();
  parts.forEach(p=>{
    if(p.includes('-')){
      const [a,b]=p.split('-').map(x=>parseInt(x,10));
      for(let i=a;i<=b;i++) set.add(i);
    }else{
      const v = parseInt(p,10);
      if(!isNaN(v)) set.add(v);
    }
  });
  return set;
}

function rollDiceForPlayer(player){
  const d1 = Math.floor(Math.random()*6)+1;
  if(player.hasStation){
    const d2 = Math.floor(Math.random()*6)+1;
    return {roll: d1 + d2, pieces:[d1,d2]};
  } else {
    return {roll: d1, pieces:[d1]};
  }
}

function applyEffects(roller, rollValue){
  const rollerPlayer = GAME.players[roller.id];
  GAME.players.forEach(p=>{
    p.buildings.forEach(b=>{
      const specSet = parseDiceSpec(b.dice);
      if(specSet.has(rollValue)){
        if(b.effect_type === 'bank_gain'){
          p.coins += b.value;
          log(`${p.name} の ${b.name} が発動：銀行から ${b.value} コイン獲得`);
        } else if(b.effect_type === 'steal_from_roller'){
          const take = Math.min(b.value, rollerPlayer.coins);
          rollerPlayer.coins -= take;
          p.coins += take;
          log(`${p.name} の ${b.name} が発動：${rollerPlayer.name} から ${take} コイン奪う`);
        } else if(b.effect_type === 'gain_from_all'){
          let total = 0;
          GAME.players.forEach(other=>{
            if(other.id !== p.id){
              const give = Math.min(b.value, other.coins);
              other.coins -= give;
              total += give;
            }
          });
          p.coins += total;
          log(`${p.name} の ${b.name} が発動：全員から合計 ${total} コイン獲得`);
        }
      }
    });
  });
  GAME.players.forEach(p=>{
    if(p.landmarks['mall']){
      p.buildings.forEach(b=>{
        const specSet = parseDiceSpec(b.dice);
        if(specSet.has(rollValue) && (b.name==='カフェ' || b.name==='レストラン')){
          p.coins += 1;
          log(`${p.name} の ショッピングモール効果：${b.name} の効果 +1 コイン`);
        }
      });
    }
  });
}

function checkVictory(player){
  const allBuilt = GAME.data.landmarks.every(l => player.landmarks[l.key]);
  if(allBuilt){
    alert(player.name + ' の勝利！おめでとうございます 🎉');
    log(player.name + ' がすべてのランドマークを建設して勝利！');
  }
}

function renderMyArea(){
  const player = GAME.players[GAME.current];
  document.getElementById('currentPlayerName').textContent = player.name;
  document.getElementById('currentPlayerCoins').textContent = player.coins;
  document.getElementById('myCards').innerHTML = '';
  document.getElementById('myLandmarks').innerHTML = '';
  player.buildings.forEach(b=>{
    const el = document.createElement('div');
    el.className = 'card';
    el.textContent = `${b.emoji} ${b.name} (目:${b.dice})`;
    document.getElementById('myCards').appendChild(el);
  });
  GAME.data.landmarks.forEach(l=>{
    const el = document.createElement('div');
    el.className = 'card';
    el.textContent = `${l.emoji} ${l.name} — ${player.landmarks[l.key] ? '建設済' : '未建設'}`;
    document.getElementById('myLandmarks').appendChild(el);
  });
  renderPlayers();
}

function nextTurn(){
  GAME.current = (GAME.current + 1) % GAME.playerCount;
  renderMyArea();
  log('ターン: ' + GAME.players[GAME.current].name + ' の番になりました。');
}

document.getElementById('setupBtn').addEventListener('click', ()=>{
  const n = parseInt(document.getElementById('playerCount').value,10);
  setupPlayers(n);
});

document.getElementById('rollBtn').addEventListener('click', ()=>{
  const player = GAME.players[GAME.current];
  const res = rollDiceForPlayer(player);
  document.getElementById('diceResult').textContent = res.pieces.join(' + ') + ' = ' + res.roll;
  log(player.name + ' がサイコロを振った：' + (res.pieces.join(' + ')) + ' = ' + res.roll);
  applyEffects(player, res.roll);
  const isDouble = res.pieces.length===2 && res.pieces[0]===res.pieces[1];
  if(isDouble && player.landmarks['amusement_park']){
    log(player.name + ' がゾロ目で遊園地効果：もう一度ターンを行える');
    renderPlayers(); renderMyArea();
    return;
  }
  renderPlayers(); renderMyArea();
});

document.getElementById('endBtn').addEventListener('click', ()=>{
  nextTurn();
});

window.addEventListener('DOMContentLoaded', ()=>{
});
