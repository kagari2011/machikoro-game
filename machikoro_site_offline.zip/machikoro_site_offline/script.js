async function loadData(){
  const res = await fetch('assets/data.json');
  const data = await res.json();
  renderTables(data);
  setupFilters();
}
function renderTables(data){
  const wrap = document.getElementById('cardsTable');
  wrap.innerHTML = '';
  const table = document.createElement('table');
  table.className = 'table';
  table.innerHTML = `
    <thead>
      <tr>
        <th>カテゴリ</th>
        <th>カード名</th>
        <th>目</th>
        <th>効果</th>
        <th>コスト</th>
        <th>推奨枚数</th>
      </tr>
    </thead>
    <tbody></tbody>
  `;
  const tbody = table.querySelector('tbody');

  // Buildings
  data.buildings.forEach(b => {
    const tr = document.createElement('tr');
    tr.dataset.category = b.type;
    tr.innerHTML = `
      <td><span class="badge ${b.type}">${b.type === 'basic' ? '基本' : '特殊'}</span></td>
      <td>${b.emoji} ${b.name}</td>
      <td>${b.dice}</td>
      <td>${b.effect}</td>
      <td>${b.cost}</td>
      <td>${data.recommended_counts[b.name] ?? '-'}</td>
    `;
    tbody.appendChild(tr);
  });

  // Landmarks
  data.landmarks.forEach(l => {
    const tr = document.createElement('tr');
    tr.dataset.category = 'landmark';
    tr.innerHTML = `
      <td><span class="badge landmark">ランドマーク</span></td>
      <td>${l.emoji} ${l.name}</td>
      <td>-</td>
      <td>${l.effect}</td>
      <td>${l.cost}</td>
      <td>各プレイヤー1枚</td>
    `;
    tbody.appendChild(tr);
  });

  wrap.appendChild(table);
}
function setupFilters(){
  document.querySelectorAll('.chip').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = btn.dataset.filter;
      document.querySelectorAll('tbody tr').forEach(tr => {
        tr.style.display = (target === 'all' || tr.dataset.category === target) ? '' : 'none';
      });
    });
  });
}
window.addEventListener('DOMContentLoaded', loadData);
